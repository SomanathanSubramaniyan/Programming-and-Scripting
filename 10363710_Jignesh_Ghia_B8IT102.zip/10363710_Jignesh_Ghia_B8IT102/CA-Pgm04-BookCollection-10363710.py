"""
Institue : Dublin Business School 
Course   : Higher Diploma in Data Analytics - Sep 2017 Intake - Part Time - Group A
Name     : Jignesh Ghia Student ID - 10363710
Module   : Prgramming Essentials 
Question : 4 - Book Collection.

ASSUMPTIONS
1. BOOK NAMES ARE ALLOWED TO HAVE SPECIAL CHARACTERS and expected to have minimum 1 character in title.
2. The program font colours are configured to suit running program from command prompt. The font colour and font background 
    may be different in different IDEs.
"""

errcolour="\033[1;35;40m"
pgmcolour="\033[1;33;40m"
resetcolour="\033[1;37;40m"

#Function that checks if the string is empty.
def checkforemptystring (inputotcheck):
    isempty=False
    if len(inputotcheck) == 0 :
        print (errcolour + "\nThe length of book name is 0.")
        isempty=True
    return isempty    

#function that performs all validations requested. This function can be expanded to add more validations.
def checkifinputinvalid (inputotcheck, validatemethods):
    result = False
    for validatemethod in validatemethods: 
        if validatemethod == "checkstrlen" :
            result = checkforemptystring (inputotcheck)
            if result == True:
                return result
    return result

#function that allows user to capture input and calls for validation. 
#function also allows user to re-enter values if entry is incorrect and terminates the program gracefully
#if user does not want to continue.
def enterinput(displaymsg, validatemethods,defaultreturnvalue):
    import sys
    continueloop=0
    while continueloop==0:
        userentered = input(resetcolour + "\n"+displaymsg)
        if checkifinputinvalid(userentered, validatemethods) == True:
            print (errcolour + "\n*** Error - Invalid Input. ***")
            if input(resetcolour + "\nType \"Y\" to continue or anything else to exit the program : ") != "Y":
                continueloop=1
                userentered = defaultreturnvalue
                print (pgmcolour + "\nThe program is being terminated - Good Bye.")
                print (resetcolour) 
                sys.exit()
        else:
            continueloop=1
    return userentered

#Main body of the program.
    
from os import system
system("cls")

print (pgmcolour + "######################################################################################")
print (pgmcolour + "WELCOME TO THE DBS CONSOLE for Student ID 10363710")
print (pgmcolour + "Enter all books you have collected. When you have finished please enter the word Exit.")
print (pgmcolour + "######################################################################################")
print (resetcolour) 
#Create empty list & ask for first book name
booklist = []
booklist.append(enterinput("Enter book name : ",["checkstrlen"],""))

#While user does not enter exit continue to ask for more books.
while ((booklist[len(booklist)-1] != "Exit") and (booklist[len(booklist)-1]!= "exit") and (booklist[len(booklist)-1]!= "EXIT")) :
    booklist.append(enterinput("Enter book name : ",["checkstrlen"],""))

#Once user enters exit then delete the last entry of the list which will have the word exit
booklist.remove(booklist[len(booklist)-1])

#Check if the list is empty; if not print all books.
if len(booklist) == 0: 
    print (resetcolour + "\n\nThere are no books collected.")
    print (pgmcolour + "\nThank you for using the book collection program - Good Bye.")
    print (resetcolour) 
else:
    print(resetcolour + "\n\nBook(s) collected are: ")
    for book in booklist:
        print (book)
    print (pgmcolour + "\nThank you for using the book collection program - Good Bye.")
    print (resetcolour) 
