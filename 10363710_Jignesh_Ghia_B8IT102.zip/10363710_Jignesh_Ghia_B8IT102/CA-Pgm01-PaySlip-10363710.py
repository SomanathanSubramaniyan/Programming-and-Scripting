"""
Institue : Dublin Business School 
Course   : Higher Diploma in Data Analytics - Sep 2017 Intake - Part Time - Group A
Name     : Jignesh Ghia Student ID - 10363710
Module   : Prgramming Essentials 
Question : 1 - Payslip.

ASSUMPTIONS
1. Name is expected to be only First Name and Last Name. Even when users have middle name they will not be allowed to enter.
2. Employee No is expected to be alphanumberic and no special characters are allowed.
3. Hourly rate and overtime rate to be greater than or equal to 0.
4. Tax rates are expected to between 0 and 100.
5. Week ending date has to be a Sunday.
6. This program can be be run in interactive mode or test mode. To run the program in test mode enter "testmode" as parameter
    from command line and keep inputs in a file called testmode-payslip-input.txt. The output is in testmode-payslip-output.txt. 
    This enables user to enter a number of inputs in one go and check the output in one file.
    To run the program in interactive mode simply call python program without any command line parameters
    Please note test mode will not have input validations. It is more designed to check calculations and format of payslip
    with number of different inputs. For checking the input validation please use interactive mode.
7. The program font colours are configured to suit running program from command prompt. The font colour and font background 
    may be different in different IDEs.
************* VALIDATION FUNCTIONS ****************************
This section defines a number of functions that are used to validate the
incoming data from users. There are function to check if the input is integers or float 
to checking if value is 0, contains a word or special characters. 
************* VALIDATION FUNCTIONS ****************************
"""     
#Font colour definations
errcolour="\033[1;35;40m"
pgmcolour="\033[1;34;40m"
resetcolour="\033[1;37;40m"
payslipcolour="\033[1;33;40m"


def checkifint(inputvalue,printmsg='Y'):
    isint=0
    try:
        int(inputvalue)
    except ValueError:
        if printmsg == 'Y' :
            print (errcolour + "\nThe input is not a integer. ")
        isint=1
    return isint    

def checkiffloat (inputvalue,printmsg='Y'):
    isfloat=0
    try:
        float(inputvalue)
    except ValueError:
        if printmsg == 'Y' :
            print (errcolour + "\nThe input is not a decimal value. ")
        isfloat=1
    return isfloat    

def checkifzero (inputvalue,printmsg='Y'):
    iszero=0
    if float(inputvalue) == 0 :
        if printmsg == "Y" :
            print (errcolour + "\nThe input is 0. Enter a non zero value.")
        iszero=1
    return iszero    

def checkforemptystr (inputvalue):
    isempty=0
    if len(inputvalue) == 0 :
        print (errcolour + "\nThe length of input is 0.")
        isempty=1
    return isempty

def checkforwords (inputvalue, numberofwords):
    result=0
    words=inputvalue.split()
    if len(words) != numberofwords :
        print (errcolour + "\nThe input does not contain exactly " + str(numberofwords) + " word(s).")
        result=1
    return result    

def checknamehasnoalphabet(inputvalue):
    result=0
    words=inputvalue.split()
    for word in words :
        if checkifwordhasnoalphabet (word) == 1:
            print (errcolour + "\nThe input word " + "\""+ word + "\" does not contain any alphabets.")
            result=1
            return result
    return result    
            
def checkifwordhasnoalphabet (inputvalue):
    result=1
    for char in inputvalue:    
        if char.isalpha():
            result=0
            return result
        else:
            result=1
    return result

def checkinputhasspecialchars(inputvalue,allowedchars=[""]):
    result=0
    words=inputvalue.split()
    for word in words :
        if checkifwordhasspecialchars (word,allowedchars) == 1:
            print (errcolour + "\nThe input word " + "\""+ word + "\" contains special characters.")
            result=1
            return result
    return result  

def checkifwordhasspecialchars (inputvalue,allowedchars=[""]):
    result=0
    for char in inputvalue:    
        if char.isalnum():
            result=0            
        elif char in allowedchars:
            result = 0 
        else:
            result=1
            return result
    return result

def checkfordateformat (inputvalue):
    import datetime
    import sys
    result=0
    #Check the string contains only 2 /
    if inputvalue.count("/") != 2 :
        print (errcolour + "\nThe date does not contain exactly 2 \"/\" in the input. Incorrect Date Format.")
        result = 1
        return result
    #Break the parts of the date and check they are all integers
    dateparts = inputvalue.split("/")
    for datepart in dateparts :
        if checkifint(datepart,"N") == 1 :
            print (errcolour + "\nThe date entered is not correct : " + inputvalue + "!")
            result = 1
            return result
    #Now Assign the dateparts for datetime.date class to check if the date is a valid date
    try:
        datentered = datetime.date(int(dateparts[2]),int(dateparts[1]),int(dateparts[0]))
    except ValueError:
        print (errcolour + "\nInvalid Date : - "+ str(sys.exc_info()[1]) +" ")
        result=1
        return result
    #Now check if the date entered is actually weekend end i.e. a Sunday
    if datentered.weekday() != 6 :
        print (errcolour + "\nDate Entered is not a week ending date i.e. a Sunday.")
        result=1
        return result
    return result

def correctdateformat(currentdate):
    import datetime
    dateparts = currentdate.split("/")
    newdate=(("00"+dateparts[0])[-2:] + "/" + \
             ("00"+dateparts[1])[-2:] + "/" + \
             ((str(datetime.datetime.now().year))[:2]+dateparts[2])[-4:])
    return newdate        

def checkhours (inputvalue):
    result=0
    if float(inputvalue) > (24*7):
        print (errcolour + "\nThe number of hours per week exceeds the maximum possible hours in a week.")
        result=1
        return result
    elif float(inputvalue) < 0 :
        print (errcolour + "\nThe number of hours cannot be less than 0.")
        result=1
        return result
    return result

def checkifnegative (inputvalue):
    result=0
    if float(inputvalue) < 0 :
        print(errcolour + "\nThe input cannot be negative value.")
        result=1
        return result
    return result

def checkiftaxratevalid(inputvalue):
    result = 0
    if float(inputvalue) < 0 or float(inputvalue) > 100:
        print(errcolour + "\nThe input cannot be less than 0 or greater than 100.")
        result=1
        return result
    return result  

#This function is written to allow payslip formatting to be correct even when all values of payslip are 0.
    #The rates and total field needs 5 spaces but the values need only 4. This function will give rates and total 
    #fields 5 spaces even if values only need 4.
def determinemaxlength(strvalue1, strvalue2, minlength=0):
    
    maxlength = max(len(strvalue1), len(strvalue2))    
    
    if maxlength < minlength:
        maxlength = minlength
    
    return maxlength      
"""
************* VALIDATION FUNCTIONS ****************************
This section ends here.
************* VALIDATION FUNCTIONS ****************************                

************* Input Capture & Calling Validation****************************
In this section 2 functions are defined. First is InputValue which present the user
with a prompt to enter values and then it called the InvalidInput function with list 
of validations it should perform for a particular input.
************* Input Capture & Calling Validation****************************                
"""

def validateinput (inputvalue, validatemethods):
    result = 0
    for validatemethod in validatemethods: 
        if validatemethod == "Integer" :
            result = checkifint(inputvalue)
            if result == 1:
                return result
        elif validatemethod == "CheckStrLen" :
            result = checkforemptystr (inputvalue)
            if result == 1:
                return result
        elif validatemethod == "CheckForWord1":
            result = checkforwords (inputvalue,1)
            if result == 1:
                return result
        elif validatemethod == "CheckForWord2":
            result = checkforwords (inputvalue,2)
            if result == 1:
                return result
        elif validatemethod == "CheckNameHasNoAlphabet":
            result = checknamehasnoalphabet (inputvalue)
            if result == 1:
                return result    
        elif validatemethod == "CheckInputHasSpecialChars":
            result = checkinputhasspecialchars (inputvalue)
            if result == 1:
                return result    
        elif validatemethod == "CheckInputHasSpecialCharsapso":
            result = checkinputhasspecialchars (inputvalue,"\'")
            if result == 1:
                return result  
        elif validatemethod == "CheckForDateFormat":
            result = checkfordateformat (inputvalue)
            if result == 1:
                return result    
        elif validatemethod == "CheckIfFloat":
            result = checkiffloat (inputvalue)
            if result == 1:
                return result 
        elif validatemethod == "CheckIfZero":
            result = checkifzero (inputvalue)
            if result == 1:
                return result 
        elif validatemethod == "CheckHours":
            result = checkhours (inputvalue)
            if result == 1:
                return result 
        elif validatemethod == "CheckIfNegative":
            result = checkifnegative (inputvalue)
            if result == 1:
                return result 
        elif validatemethod == "checkiftaxratevalid":
            result = checkiftaxratevalid (inputvalue)
            if result == 1:
                return result            
            
    return result

#function that allows user to capture input and calls for validation. 
#function also always user to enter values if entry is incorrect and terminates the program gracefully
#if user does not want to continue.
def enterinput (displayMsg, validatemethods,defaultreturnvalue):
    import sys
    continueloop=0
    while continueloop==0:
        userentered = input(resetcolour + "\n"+displayMsg)
        if validateinput (userentered, validatemethods) == 1:
            print (errcolour + "\n*** Error - Invalid Input. ***")
            if input(resetcolour + "\nType \"Y\" to continue or anything else to exit the program : ") != "Y":
                continueloop=1
                userentered=defaultreturnvalue
                print (pgmcolour + "\nThe program is being terminated - Good Bye.")
                print (resetcolour) 
                sys.exit()
        else:
            continueloop=1
    return userentered


"""
**************** Input Capture & Calling Validation****************************
This section ends here.
**************** Input Capture & Calling Validation****************************                
***************Main Program Body Starts here ******************************

"""

def runpgmintestmode():
    import os
    import sys
    os.system("cls")
    print (pgmcolour + "\nThe program is being run in TEST mode.")
    try:
        fname=open("testmode-payslip-input.txt","r")
    except FileNotFoundError:
        print (errcolour + "\nThere is no \"testmode-payslip-input.txt\" file from where inputs can be read.")
        print (pgmcolour + "\nThe program is being terminated - Good Bye.")
        print (resetcolour) 
        sys.exit()
        
    inputvaluelist=fname.readlines()
    fname.close()
    
    for inputvalues in inputvaluelist:
        calculatepayslip((inputvalues.strip().split(",")))
    
    print (resetcolour + "\nThe output is stored in testmode-payslip-output.txt.")
    print (pgmcolour + "\n\nThank you for using the payslip program - Good Bye.")
    print (resetcolour) 
    
def calculatepayslip (inputvalues=[]):
    
    import os
    os.system("cls")
    
    print (pgmcolour + "n###################################################################################")
    print (pgmcolour + "WELCOME TO THE DBS CONSOLE for Student ID 10363710")
    print (pgmcolour + "###################################################################################")
    print (resetcolour)           
    
    
    """
    ************* CALLING INPUT AND VALIDATE FUNCTIONS ****************************
    Capturing the input with enforcing validations to ensure correct input is captured.
    Where user does not enter right values they are given error messages of what is wrong.
    They are then given option to exit the program or re-enter the input
    
    ASSUMPTIONS
    1. Name is expected to be only First Name and Last Name. Even when users have middle name they will not be allowed to enter.
    2. Employee No is expected to be alphanumberic and no special characters are allowed.
    3. Hourly rate and overtime rate to be greater than or equal to 0.
    4. Tax rates are expected to be greater than or equal to 0.
    5. Week ending date has to be a Sunday.
    ************* CALLING INPUT AND VALIDATE FUNCTIONS ****************************
    """
    # Initialising the variables
    empname=""
    empno=""
    weekending=""
    noofhoursworked=0.0
    hourlyrate=0.0
    overtimerate=0.0
    standardtaxrate=0.0
    overtimetaxrate=0.0
    
    if len(inputvalues) == 0:
        
        empname=enterinput ("Enter Employee Name as <FirstName LastName> : ",["CheckStrLen","CheckForWord2","CheckInputHasSpecialCharsapso", "CheckNameHasNoAlphabet"],"")
        
        empno=enterinput ("Enter Employee Number : ",["CheckStrLen","CheckForWord1", "CheckInputHasSpecialChars"],"")
        
        weekending=enterinput ("Enter week ending date in \"dd/mm/yyyy\" format : ", ["CheckStrLen","CheckForDateFormat"],"01/01/1900")
        
        noofhoursworked=float(enterinput("Enter the number of hours worked :- ",["CheckIfFloat","CheckIfNegative","CheckHours"],0.0))
        
        hourlyrate=float(enterinput("Enter the Hourly Rate :- ",["CheckIfFloat","CheckIfNegative"],0.0))
        
        overtimeratemultiple=float(enterinput("Enter the Overtime Rate as multiply of Hourly Rate :- ",["CheckIfFloat","CheckIfNegative"],0.0))
        
        standardtaxrate=float(enterinput("Enter the Standard Tax Rate :- ",["CheckIfFloat","checkiftaxratevalid"],0.0))
        
        overtimetaxrate=float(enterinput("Enter the Overtime Tax Rate :- ",["CheckIfFloat","checkiftaxratevalid"],0.0))
        
        #Padding the week ending date so that it is in dd/mm/yyyy format even when user enters d/m/yy
        weekending=correctdateformat(weekending)
        
    else:     
        empname=inputvalues[0]
        empno=inputvalues[1]
        weekending=inputvalues[2]
        noofhoursworked=float(inputvalues[3])
        hourlyrate=float(inputvalues[4])
        overtimeratemultiple=float(inputvalues[5])
        standardtaxrate=float(inputvalues[6])
        overtimetaxrate=float(inputvalues[7])
    
    """    
    ************* CALLING INPUT AND VALIDATE FUNCTIONS ****************************
    This section ends here.
    ************* CALLING INPUT AND VALIDATE FUNCTIONS ****************************
    
    ************* CALCULATING PAYSLIP VALUES AND FORMATTING ***********************
    In this section various fields of payslip are calculated. Overtime hours are determined,
    normal and overtime pay and taxes are calculated and then total are made.
    This section also converts the calculate and entered fields into the right string formats.
    This enables the next section to derive the correct position and lenght of fields
    on the payslips. The lenghts are variable since normal rate, normal pay, standard deductions
    and their overtime counter parts depend on the values entered by user.
    ************* CALCULATING PAYSLIP VALUES AND FORMATTING ***********************
    """
    #Calcuate Overtime hours
    stdworkinghours = 37.5
    overtimehours=0.00
    if noofhoursworked > stdworkinghours :
        overtimehours = noofhoursworked - stdworkinghours
        normalhours = stdworkinghours
    else:
        normalhours=noofhoursworked
       
    #Calculate normal hours pay
    normalhourspay = normalhours * hourlyrate
    strnormalhourspay = str('{0:,.2f}'.format(normalhourspay))
    
    #Calculate overtime pay
    overtimerate  = overtimeratemultiple * hourlyrate
    overtimepay = overtimehours * overtimerate 
    strovertimepay = str('{0:,.2f}'.format(overtimepay))
    
    #Calculate NormalPayTax
    normalpaytax = normalhourspay * (standardtaxrate/100)
    strnormalpaytax = str('{0:,.2f}'.format(normalpaytax))
    
    #Calculate OvertimePayTax
    overtimepaytax = overtimepay * (overtimetaxrate/100)
    strovertimepaytax = str('{0:,.2f}'.format(overtimepaytax)) 
    
    #Calculate TotalPay
    totalpay = normalhourspay + overtimepay
    strtotalpay = str('{0:,.2f}'.format(totalpay))
    
    #Calculate TotalDeductions
    totaldeductions = normalpaytax + overtimepaytax
    strtotaldeductions = str('{0:,.2f}'.format(totaldeductions))
    
    #Calculate NetPay
    netpay = totalpay - totaldeductions
    strnetpay = str('{0:,.2f}'.format(netpay))
    
    #format the variables so that they can be used to determine the right lenght of line & starting positions for the payslip
    strovertimehours = str('{0:,.2f}'.format(overtimehours))
    strnormalhours = str('{0:,.2f}'.format(normalhours))
    
    strhourlyrate = str('{0:,.2f}'.format(hourlyrate))
    strovertimerate = str('{0:,.2f}'.format(overtimerate))
    
    strstandardtaxrate = str('{0:,.2f}'.format(standardtaxrate))
    strovertimetaxrate = str('{0:,.2f}'.format(overtimetaxrate))
    
    
    """    
    ************* CALCULATING PAYSLIP VALUES AND FORMATTING ***********************
    This section ends here.
    ************* CALCULATING PAYSLIP VALUES AND FORMATTING ***********************
    
    ************************** DETERMINING FIELD LENGTHS **************************
    This section determines the maximum length of lines of the payslip.
    It uses that to space all lines within the paylsip. For example the first line is
    centered based on the maximum length of line that payslip will need for a given run. 
    Large normal rates and long hours worked will result in bigger values of normal pay and tax.
    ************************** DETERMINING FIELD LENGTHS **************************    
    """
    
    #The hours length is being fixed as the max weekly hours length will not exceed 6    
    maxhourslength = 6
    
    maxratelength = determinemaxlength(strhourlyrate,strovertimerate,len("Rates"))
    
    maxpaylength = determinemaxlength(strnormalhourspay,strovertimepay,len("Total"))
    
    maxtaxratelength = max(len(strstandardtaxrate),len(strovertimetaxrate))
    
    maxtaxlength = max(len(strnormalpaytax),len(strovertimepaytax))

    #calculate maximum length of the 3 total fields to ensure that "€" sign is in same place in output
    maxtotalslength = max(len(strtotalpay), len(strtotaldeductions), len(strnetpay))
    
    #Calculate the max line size - This is done by adding literals and various lengths of variables
    maxlinelength = 18 + maxratelength + 1 + maxhourslength + 1 + maxpaylength +1 + 7 + maxtaxratelength + 2 + maxtaxlength              
    
    """
    ************************** DETERMINING FIELD LENGTHS **************************
    This section ends here.
    ************************** DETERMINING FIELD LENGTHS **************************
    
    ************************** CREATING PAYSLIP LINES *****************************
    In this section a list of payslip lines are created with correct formatting and spacing.
    Format function is used in earlier section to get fields in right format e.g. all decimals are in 0.00 format.
    Format function is used in this section to pad the fields with right amount of space and align them left or right.
    ************************** CREATING PAYSLIP LINES *****************************
    """
    print ("\n\n")
    
    #Create list of paylsip lines with formatted string for each lines
    payslip = []
    
    payslip.append("\n")
    
    #Create Line 1 no with word Payslip centered within max length of line.
    payslip.append('{0:^{1}}'.format('P A Y S L I P',maxlinelength) )
    
    payslip.append("\n")
    
    payslip.append ('{0:<{1}}'.format ("WEEK ENDING " + weekending, maxlinelength))
    
    payslip.append ('{0:<{1}}'.format ("Employee: " + empname, maxlinelength))
    
    payslip.append ('{0:<{1}}'.format ("Employee Number: " + empno, maxlinelength))
    
    #Start Earnings from 26 as all text preceeding it is fixed legths - 
    #Start Deduction by calculating start position = max line length - the max length for tax - space required for Tax rate
    payslip.append ("\n")
    
    payslip.append ('{0:>{1}}{2:>{3}}{4}'.format("Earnings",27,"",maxratelength+maxpaylength ,"Deductions" ))
    
    payslip.append('{0:>{1}}{2:<{3}}{4:<{5}}'.format("HOURS ",25,\
                                             "RATES",maxratelength+1,
                                             "TOTAL",maxpaylength+1  )   ) 
    
    #maxlinelength = 18 + maxratelength + 1 + maxhourslength + 1 + maxpaylength +1 + 7 + maxtaxratelength + 2 + maxtaxlength       
    payslip.append('{0:<{1}}{2:>{3}}{4:>{5}}{6:>{7}}{8:<{9}}{10:>{11}}{12:>{13}}'\
                   .format("HOURS (Normal)",18,\
                   strnormalhours,maxhourslength,\
                   strhourlyrate, maxratelength+1,\
                   strnormalhourspay, maxpaylength+1,\
                   " TAX @ ", 7, \
                   strstandardtaxrate + "% ",maxtaxratelength+2,\
                   strnormalpaytax,maxtaxlength \
                   )) 
    
    payslip.append('{0:<{1}}{2:>{3}}{4:>{5}}{6:>{7}}{8:<{9}}{10:>{11}}{12:>{13}}'\
                   .format("HOURS (Overtime)",18,\
                   strovertimehours,maxhourslength,\
                   strovertimerate, maxratelength+1,\
                   strovertimepay, maxpaylength+1,\
                   " TAX @ ", 7, \
                   strovertimetaxrate + "% ", maxtaxratelength+2, \
                   strovertimepaytax,maxtaxlength \
                   )) 
    
    payslip.append ("\n")
    
    payslip.append ('{0:>{1}}{2:{3}}{4:{5}}{6:>{7}}' \
                    .format("TOTAL PAY:",29, \
                    "",maxlinelength-29-2-maxtotalslength-1, \
                    "€ ",2, \
                    strtotalpay,maxtotalslength \
                    ))   
    
    payslip.append ('{0:>{1}}{2:{3}}{4:{5}}{6:>{7}}' \
                    .format("TOTAL DEDUCTIONS:",36, \
                    "",maxlinelength-36-2-maxtotalslength-1, \
                    "€ ", 2, \
                    strtotaldeductions,maxtotalslength  \
                    ))   
    
    payslip.append ('{0:>{1}}{2:{3}}{4:{5}}{6:>{7}}' \
                    .format("NET PAY:",27, \
                    "",maxlinelength-27-2-maxtotalslength-1, \
                    "€ ", 2, \
                    strnetpay,maxtotalslength  \
                    ))  
    """
    ************************** CREATING PAYSLIP LINES *****************************
    This section ends here.
    ************************** CREATING PAYSLIP LINES *****************************                
    """
    
    if len(inputvalues) == 0:
        #print the payslip on screen.
        for line in payslip:
            print (payslipcolour + line)
        print (pgmcolour + "\n\nThank you for using the payslip program - Good Bye.")
        print (resetcolour) 
    else:
        #creating payslip in file
        fname=open("testmode-payslip-output.txt","a")
        for line in payslip:
            fname.write(line+"\n")
        fname.close()
        
        
    """
    ************************** CREATING PAYSLIP LINES *****************************
    This is end of Calculate Payslip function.
    ************************** CREATING PAYSLIP LINES *****************************                
    """
    
#This allows user testing of the program with input via a file called testmode-payslip-input.txt
import os

if len(os.sys.argv) > 1: 
    if os.sys.argv[1] == "testmode":
        runpgmintestmode()
    else:
        print ("\n **** To run program in test mode input first parameter as \"testmode\". ***")
        print ("\n **** To run program in interactive mode input then don't enter any parameters. ***")
else:
    calculatepayslip()
