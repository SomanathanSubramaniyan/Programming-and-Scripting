"""
Institue : Dublin Business School 
Course   : Higher Diploma in Data Analytics - Sep 2017 Intake - Part Time - Group A
Name     : Jignesh Ghia Student ID - 10363710
Module   : Prgramming Essentials 
Question : 2 - UserName\DomainName.
ASSUMPTIONS
1. Input must have single slash, user name and domian name cannot be blank, and user name and domain name
    cannot have special characters except "-" , "_" & "."
2. The program font colours are configured to suit running program from command prompt. The font colour and font background 
    may be different in different IDEs.
"""

errcolour="\033[1;35;40m"
pgmcolour="\033[1;33;40m"
resetcolour="\033[1;37;40m"

#Check if input has any special characters. This function breaks the input into words by splitting using splitchar.
#It then passes each word to another function where each char is check. 
#All special chars except "-" , "_" & "." will be marked as invalid input.
def hasspecialchars(inputvalue,allowedspecialchars,splitchar=" "):
    result=0
    words=inputvalue.split(splitchar)
    if wordhasspecialchars(words[0],allowedspecialchars) == 1:
            print (errcolour + "\nThe domain name cannot contain special characters except \"-\" or \"_\" or \".\".")
            result=1
    elif wordhasspecialchars(words[1],allowedspecialchars) == 1:
            print (errcolour + "\nThe user name cannot contain special characters except \"-\" or \"_\" or \".\".")
            result=1        
    return result  

#Checks if input contains any special chars except "-" & "_" & "."
def wordhasspecialchars (inputvalue,allowedspecialchars):
    result=0
    for char in inputvalue:    
        if char.isalnum():
            result=0
        elif char in allowedspecialchars:
            result=0
        else:
            result=1
            return result
    return result

#Function that checks if the string is empty.
def checkforemptystr (inputvalue,printmsg="Y"):
    isempty = 0
    if len(inputvalue) == 0 :
        if printmsg=="Y":
            print (errcolour + "\nThe length cannot be 0.")
        isempty = 1
    return isempty    

#Function to check that there is only a single slash in input
def checkforsingleslash(inputvalue,splitchar):
    result = 0
    if inputvalue.count(splitchar) != 1:
        print(errcolour + "\nThe number of \""+ splitchar + "\" in input has to be exactly 1.")
        result=1
    return result

#Function to split input into 2 words and check they either username or domain is blank.
def checkifuesrordomainisblank(inputvalue,splitchar=" "):
    result = 0
    parts = inputvalue.split(splitchar)
    if checkforemptystr(parts[0],"N"):
            print (errcolour + "\nThe domain name cannot be blank.")
            result = 1
            
    elif checkforemptystr(parts[1],"N"):
            print (errcolour + "\nThe user name cannot be blank.")
            result = 1
            
    return result        
 
#Function to check if either username or domain name contains only 1 special characters.

def hasonlysinglespecialchar(inputvalue,allowedspecialchars,splitchar=" "):
    result = 0 
    parts = inputvalue.split(splitchar)
    if len(parts[0]) == 1 and parts[0] in allowedspecialchars:
            print (errcolour + "\nThe domian name cannot have just 1 special character.")
            result = 1
    elif len(parts[1]) == 1 and parts[1] in allowedspecialchars:
            print (errcolour + "\nThe user name cannot have just 1 special character.")
            result = 1
    return result
    
#function that performs all validations requested. This function can be expanded to add more validations.
def validateinput (inputvalue, validatemethods):
    
    result = 0
    allowedspecialchars = ["-","_","."]
    splitchar = "\\"
    
    for validatemethod in validatemethods: 
        if validatemethod == "CheckStrLen" :
            result = checkforemptystr (inputvalue)
            if result == 1:
                return result
        elif validatemethod == "CheckforSingleSlash":
            result = checkforsingleslash (inputvalue,splitchar)
            if result == 1:
                return result
        elif validatemethod == "CheckifUesrDomainisBlank":
            result = checkifuesrordomainisblank (inputvalue,splitchar)
            if result == 1:
                return result
        elif validatemethod == "CheckInputHasSpecialChars":
            result = hasspecialchars (inputvalue,allowedspecialchars,splitchar)
            if result == 1:
                return result
        elif validatemethod == "hasonlysinglespecialchar":
            result = hasonlysinglespecialchar (inputvalue,allowedspecialchars, splitchar)
            if result == 1:
                return result
    return result

#function that allows user to capture input and calls for validation. 
#function also always user to enter values if entry is incorrect and terminates the program gracefully
#if user does not want to continue.
def enterinput(displaymsg, validatemethods,defaultreturnvalue):
    import sys
    continueloop=0
    while continueloop==0:
        inputvalue=input(resetcolour + "\n"+displaymsg)
        if validateinput(inputvalue, validatemethods) == 1:
            print (errcolour + "\n*** Error - Invalid Input. ***")
            if input(resetcolour + "\nType \"Y\" to continue or anything else to exit the program : ") != "Y":
                continueloop=1
                inputvalue=defaultreturnvalue
                print (pgmcolour + "\nThe program is being terminated - Good Bye.")
                print (resetcolour) 
                sys.exit()
        else:
            continueloop=1
    return inputvalue

#Main body of program
    
import os
os.system("cls")
    
print (pgmcolour + "\n###################################################################################")
print (pgmcolour + "WELCOME TO THE DBS CONSOLE for Student ID 10363710")
print (pgmcolour + "###################################################################################")
print (resetcolour)             
      
usrname= enterinput(resetcolour + "\nEnter your username as \"<domainname>\\<username>\" : ",["CheckforSingleSlash","CheckifUesrDomainisBlank","CheckInputHasSpecialChars","hasonlysinglespecialchar"],"")

print(resetcolour + "\n\nDomain   : " + usrname[:usrname.find("\\")] + "\n" + "UserName : " + usrname[usrname.find("\\")+1:])

print (pgmcolour + "\nThank you for using the User\\Domain program - Good Bye.")
print (resetcolour) 
