"""
Institue : Dublin Business School 
Course   : Higher Diploma in Data Analytics - Sep 2017 Intake - Part Time - Group A
Name     : Jignesh Ghia Student ID - 10363710
Module   : Prgramming Essentials 
Question : 3 - Values and Frequency.
Note     :
    The program font colours are configured to suit running program from command prompt. The font colour and font background 
    may be different in different IDEs.
"""
errcolour="\033[1;35;40m"
pgmcolour="\033[1;33;40m"
resetcolour="\033[1;37;40m"

#This function checks if the input is integer
def checkifinteger(x):
    isinteger=0
    try:
        int(x)
    except ValueError:
        isinteger=1
    return isinteger            

#This function asks user to enter a valid no of elements, checks if input is an integer greater than 0,
#if not then user has option to exit the program or re-enter.
def enternoofelements():
    continueloop=0

    while continueloop == 0:
        noofelements = input (resetcolour + "\nEnter the number of elements to be stored in the list: ")
        if checkifinteger(noofelements)==1:
            print (errcolour + "\n*** Error - Number of elements in the list has to be integer ***")
            if input (resetcolour + "\nType 'Y' to continue; anything else to exit: ") != "Y":
                continueloop=1
                noofelements=-99
        elif checkifinteger(noofelements)==0:
            if int(noofelements) <= 0:
                print (errcolour + "\n*** Error - Number of elements in list has to be greater than 0 ***")
                if input (resetcolour + "\nType 'Y' to continue; anything else to exit: ") != "Y":
                    continueloop=1
                    noofelements=-99
            else:
               continueloop=1
        
    return int(noofelements)  

#This function asks user to enter the elements of the list. It validates that they are integers.
#If not then it will give user chance to re-enter or exit the program.
# The input message is formatted so that user always enters input value from same position on each line.
def enterinput(index, totalnoofelements):
    import sys
    validentry=0
    elementofthelist = input (resetcolour + '{0}{1:>{2}}{3}'.format("element - ", str(index),len(str(totalnoofelements)), " : "))
    while validentry == 0:    
        try:
            int(elementofthelist)
            validentry=1
        except ValueError:
            validentry = 0
            elementofthelist = input (resetcolour + '{0}{1:>{2}}{3}'.format(errcolour + "Invalid Entry. Enter \"X\" to exit or Re-enter element as integer - ", str(index),len(str(totalnoofelements)),  " : "))
            if elementofthelist == "X":
                print ("\033[1;33;40m\nThe program is being terminated - Good Bye.")
                print ("\033[1;37;40m") 
                sys.exit()
    
    return elementofthelist    

#This function provides maximum length of either key or value in dictionary variable.
#This allows program to format the output such that "occurs and "times" appear on same
#position irrespective of length of key or value.
def getmaxlength (dictinput,whattomeasure):
    
    if whattomeasure not in ("key", "value"):
        print(errcolour + "\n Error in GetMaxLength function. Invalid Inputs." )
        maxlen=-99
        return maxlen
    
    maxlen=0
    for key in dictinput.keys():
        if whattomeasure == "key":
            if len(str(key)) > maxlen:
                maxlen = len(str(key))
        elif whattomeasure == "value":
            if len(str(dictinput[key])) > maxlen:
                maxlen = len(str(dictinput[key]))
    return maxlen            
            
#Main body of the program.

import os
os.system("cls") 
       
print (pgmcolour + "###################################################################################")
print (pgmcolour + "WELCOME TO THE DBS CONSOLE for Student ID 10363710")
print (pgmcolour + "###################################################################################")
print (resetcolour)  
#Get the number of elements of the list
noofelements = enternoofelements()

#Check if user wants to exit the program; if not get the elements of the list.
if noofelements != -99:
    elements = dict()
    print (resetcolour + "\nEnter " + str(noofelements) + " integer elements in the list : ")
    for index in range(1,noofelements+1):
        element = enterinput(index, noofelements+1)
        elements[element] = elements.get(element,0) + 1

#Get maximum length of the element - it will be used in output formatting
    maxlengthofkey = getmaxlength(elements,"key")

#Get maximum length of the occurance - it will be used in output formatting
    maxlengthofvalue = getmaxlength(elements,"value")

#Print all the elements such that "occurs" and "times" are in same position for all lines.
    print (resetcolour + "\nThe frequency of all elements in the list :\n")            
    for key in elements.keys():
        print (resetcolour + '{0:<{1}}{2}{3:>{4}}{5}'.format(str(key),maxlengthofkey," occurs ", str(elements[key]), maxlengthofvalue, " times "))
    print (pgmcolour + "\nThank you for using the histogram program - Good Bye.")
    print (resetcolour) 

else:
    print (pgmcolour + "\nThe program is being terminated - Good Bye.")
    print (resetcolour) 
